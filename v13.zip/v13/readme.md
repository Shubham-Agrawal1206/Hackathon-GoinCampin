# Goin'Campin'
## first unzip the folder and setup the mongodb if not set up
### Then run mongod in mongodb to start mongodb server
#### Then run node app.js in root directory to start the server of main application
##### Then type http://localhost:3000 in your web browser to surf the web server
